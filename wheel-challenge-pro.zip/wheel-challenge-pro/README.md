
# Wheel Challenge Pro

Profesjonalna imprezowa gra webowa.

Wersja: 0.9.0

## Uruchomienie
Wrzuć pliki na hosting i otwórz index.html
